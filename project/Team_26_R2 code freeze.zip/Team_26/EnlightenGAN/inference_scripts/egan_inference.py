from enlighten_inference import EnlightenOnnxModel
import cv2
name = '/image/path.ext'
img = cv2.imread(name)
model = EnlightenOnnxModel()

processed = model.predict(img)
cv2.imwrite('./output_'+name,processed)
cv2.imshow('Output',processed)
cv2.waitKey(0)
cv2.destroyAllWindows()