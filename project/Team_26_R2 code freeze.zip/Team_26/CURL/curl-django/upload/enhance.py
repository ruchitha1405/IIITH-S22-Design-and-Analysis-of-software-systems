import os
from .curl_inference import curl 
def enhance() :
    # curl("./media/images", "./upload/static/images_y")
    curl("./media/images", "./media/images_y")

