from django.contrib import admin
from upload.models import UploadedImage

# Register your models here.
admin.site.register(UploadedImage)