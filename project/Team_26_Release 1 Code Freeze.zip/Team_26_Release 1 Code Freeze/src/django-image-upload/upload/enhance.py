import os
import cv2
from enlighten_inference import EnlightenOnnxModel

def enhance() :
    model = EnlightenOnnxModel()
    path = './media/images/'
    for filename in os.listdir(os.path.join(path)):
        print(filename)
        img = cv2.imread(path + filename)
        processed = model.predict(img)
        cv2.imwrite('./media/images_x/' + filename, processed)
        os.unlink(path + filename)