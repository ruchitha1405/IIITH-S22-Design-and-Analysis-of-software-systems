# django-image-upload

### Instructions:
- pip3 install django
- pip3 install mysqlclient
- pip3 install Pillow
- update DB settings in settings.py
- python3 manage.py migrate