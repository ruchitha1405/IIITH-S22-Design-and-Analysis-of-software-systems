# clash-of-clans

### Huts:

- max health=45

 - '!'- hut1

 - '@' -hut2

 - '#'-hut3

 - '$'-hut4

 - '%'-hut5


### Spawning points:


- '1'-sp1

- '2'-sp2

- '3'-sp3


### Town hall:

- max health=90


### walls:

- max health=50


### building:

 - max health=50

 - '{'-building1

 - '}'-building2



### cannons:

- default damage value=30

- max health =60

- '<' -cannon1

- '>'-cannon2




