class spell:
    def __init__(self):
        self.POIHealth=0
        self.POIDamage=0
        self.POISpeed=0
    
    def Attack(self):
        pass

class ragespell(spell):
    def __init__(self):
        spell.__init__(self)
        self.POIDamage=100
        self.POISpeed=100
    
    def Attack(self): # method overriding (POLYMORPHISM)
        pass # need to code



RageSpell = ragespell()

# RageSpell.Attack() -> to activate ragespell

class healspell(spell):
    def __init__(self):
        spell.__init__(self)
        self.POIHealth=150
        
    
    def Attack(self): # method overriding (POLYMORPHISM)
        pass # need to code


HealSpell = healspell()

"""def RageSpell():
    pass
def HealSpell():
    pass"""