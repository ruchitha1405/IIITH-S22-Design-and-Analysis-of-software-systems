



class characteristics:
    Damage = -1 
    Health = -1
    Speed =-1

