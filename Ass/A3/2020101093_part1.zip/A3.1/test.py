import input
from colorama import Fore, Back, Style
getch = input.Get()

while(1):
    ch = input.input_to(getch)
    #ch has the char entered
    if ch == 'q':
        break
    else:
        print(Back.WHITE + Fore.RED + "Coloring is done")
