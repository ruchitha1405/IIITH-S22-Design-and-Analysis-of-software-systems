#import numpy as np
import colorama
from colorama import Fore, Back, Style

colorama.init(autoreset=True)

vil=[]
walls=[]

class point:
    def __init__(self,x,y):
        self.x=x
        self.y=y

class SP():
    def __init__(self,point,key):
        self.x=point.x
        self.y=point.y
        self.key=key
        self.CreateSP()
    def CreateSP(self):
        vil[self.x][self.y]=self.key
        
class cannon:
    def __init__(self,x,y,size,range,sym,damage_value):
        self.x=x
        self.y=y
        self.Size=size #should same as Size of cannon defined in vilage class
        self.Range=range
        self.sym=sym
        self.DamageValue=damage_value
        self.health=60
        self.create()
    def create(self):
        vil[self.x][self.y]=self.sym

class hut:
    def __init__(self,x,y,sym):
        self.x=x
        self.y=y
        self.sym=sym
        self.health=45
        self.create()
    def create(self):
        vil[self.x][self.y]=self.sym
        

class building:
    def __init__(self,x,y,size,sym):
        self.x=x
        self.y=y
        self.size=size
        self.sym=sym
        self.health=50
        self.create()
    def create(self):
        vil[self.x][self.y]=self.sym

def CreateTH(m,n):
    tm= (int)((m+1)/2) -1
    tn= (int)((n)/2 )-1
    #print(tm,tn)
    i=tn-1
    while i<tn+3:
        j=tm-1
        while j<tm+2:
            vil[i][j]='t'
            j+=1
        i+=1   
    
    """
    for i in range(len(vil)) :
        if i>tn-2 and i<tn+3: 
            for j in range(len(vil[i])) :
                if j> tm-2 and j<tm+2: 
                    vil[i][j]='t'  #not working
                    """
"""
class wall:
    def __init__(self,x,y):
        self.x=x
        self.y=y
        self.health=50
        self.Create()
    def Create(self):
        vil[self.x][self.y]='w'

"""
    
def CreateWalls(m,n):
    #wm=tm-2 # upto tm +4
    #wn=tn-2 # upto tn+5
    # need to be coded
    tm= (int)((m+1)/2) -1
    tn= (int)((n)/2 )-1
    #print(tm,tn)
    j=tm-3
    i=tn-3
    while j<tm+4:
        vil[i][j]='w'
        vil[tn+4][j]='w'
        j+=1
    while i<tn+5:
        vil[i][tm-3]='w'
        vil[i][tm+3]='w'
        i+=1

    

class village:
    
        
    def __init__(self,n,m,NumOfHuts,SizeOfHut,point1,point2,point3,NumOfWalls,NumOfCannons,SizeofCannon,NumOfBuildings):
        self.n=n #rows,need to be defined
        self.m=m # columns need to be defined
        self.NumOfHuts=NumOfHuts #atlest 5
        self.SizeOfHut= SizeOfHut#need to defined
        self.SpawnPoint1=point1#need to defined
        self.SpawnPoint2=point2#need to defined
        self.SpawnPoint3=point3#need to defined
        self.NumOfWalls=NumOfWalls #to protect townhall from troops
        self.NumOfCannons=NumOfCannons # atleast 2
        self.SizeOfCannon=SizeofCannon #need to defined
        self.NumOfBuildings=NumOfBuildings#need to defined
        self.SizeOfBuildings=1 
        self.key1='1'
        self.key2='2'
        self.key3='3'
        
    
    def create(self):
        """
        s-spawning points,t-town hall,h-huts,w-wall, c-cannon,b-building
        k-king,B-barbarian,
        " "- empty   
        """
        """
        mylist=[]
        i=0
        while  i < self.m :
            mylist.append(" ")
            i+=1
        
        i=0
        while i< self.n :
            #addlist=
            vil.append(mylist)
            i+=1
         """
        
        
        i = 0
        while i < self.n:
            temp = []
            j = 0
            while j < self.m:
                temp.append(" ")
                j = j+1
            vil.append(temp)
            i = i + 1
            
        # created empty village
        
           
        
        """j=tn-1
        while j<tn+3:
            vil[j][tm-1:tm+2]=['t','t','t']
            i=tm-1
            while i <tm+2:
                vil[j][i]='t'
                i+=1
            j+=1"""
        
        CreateTH(self.m,self.n)
        self.MaxHealthTH=90
        self.CurrentHealthTH=90
        
        # created town hall
        self.hut1= hut(11,5,'!',)
        self.hut2=hut(5,8,'@')
        self.hut3=hut(6,2,'#')
        self.hut4=hut(10,23,'$')
        self.hut5=hut(17,15,'%')

        self.MaxHealthHut=45
        #self.hutlist=['!','@','#','$','%']
        # created huts
        """
         i = 0
        while i < self.n:
            temp = []
            j = 0
            while j < self.m:
                temp.append(" ")
                j = j+1
            vil.append(temp)
            i = i + 1
        """
        CreateWalls(self.m,self.n)
        # created walls around town hall

        self.sp1=SP(self.SpawnPoint1,self.key1)
        self.sp2=SP(self.SpawnPoint2,self.key2)
        self.sp3=SP(self.SpawnPoint3,self.key3)
        
        # created spawning points
        self.RangeOfCannon=6
        self.DamageOfCannon=30
        self.c1=cannon(15,15,self.SizeOfCannon,self.RangeOfCannon,'<',self.DamageOfCannon)
        self.c2=cannon(11,2,self.SizeOfCannon,self.RangeOfCannon,'>',self.DamageOfCannon)
        #created cannons
         
        self.MaxHealthBuilding=50
        self.b1=building(3,15,self.SizeOfBuildings,'{')
        self.b2=building(10,9,self.SizeOfBuildings,'}')
        #created  buildings
        #print(vil)
        del(i)
        del(j)
        for i in vil:
            for j in i:
                if j==" ":
                    print(Back.GREEN + f"{j} ", end ="")
                else:
                   print(Back.MAGENTA + f"{j} ", end ="")

            print("")
        
        del(i)
        del(j)
        #print("xyz")
        #created empty village








