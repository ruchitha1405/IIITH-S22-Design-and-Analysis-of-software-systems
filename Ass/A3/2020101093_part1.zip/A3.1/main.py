import colorama
import os


import village 


if __name__ == '__main__':
    colorama.init()
    os.system('clear')
    sp1=village.point(1,3)
    sp2=village.point(3,4)
    sp3=village.point(5,6)
    Village=village.village(20,31,5,1,sp1,sp2,sp3,1,2,1,2)
    Village.create()

