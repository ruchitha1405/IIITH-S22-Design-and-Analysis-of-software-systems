from gameobj import characteristics


class barbarians(characteristics): # INHERITANCE
    def __init__(self,damage,health,speed):
        self.Damage=damage
        self.Health=health
        self.Speed=speed

    