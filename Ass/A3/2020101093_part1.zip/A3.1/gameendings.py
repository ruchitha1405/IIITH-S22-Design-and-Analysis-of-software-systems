def CheckEnd():
    if():
        print("Victory")
    elif():
        print ("Defeat")
    else :
        return -1
    