

from gameobj import characteristics


class king(characteristics): # INHERITANCE
    def __init__(self,speed):
        self.UpKey='W'
        self.LeftKey='A'
        self.DownKey='S'
        self.RightKey='D'
        self.Speed=speed #need to be defined
        self.AttackKey=' ' # <SPACE>

    def Attack(self):
        pass # need to be coded
    def MoveUp(self):
        pass # need to be coded
    def MoveLeft(self):
        pass # need to be coded
    def MoveDown(self):
        pass  # need to be coded
    def MoveRight (self):
        pass # need to be coded

