
#import colorama
from  colorama import Fore,Back,Style
#from village import cannons,buildings,huts,barbarians
#from main import Village
import builtins

def CheckEnd(Village,lead,cannons,towers,buildings,huts,barbarians,count_bar , max_bar,level):
    
    win = 1
    for i in cannons:
        if i.health > 0: 
            win = 0
            break
    for i in towers:
        if i.health > 0: 
            win = 0
            break 
    for i in buildings:
        if i.health > 0: 
            win = 0
            break
    for i in huts:
        if i.health > 0: 
            win = 0
            break
    if Village.TH.health > 0: 
        win = 0
    
    if win == 1:    
        print(Fore.RED + "You are victorious" + Fore.RESET)
        
        if (level==3):
            c=builtins.input("Do you want to go to next level (y/n) :")
            if(c=="y"):
                print("there are no further levels")
                exit()
            elif(c=='n'):
                return level
            else :
                print("INVALID INPUT")
                exit()
        else:
            c=builtins.input("Do you want to go to next level (y/n) :")
            if(c=="y"):
                return (level+1)
            elif(c=='n'):
                return level
            else :
                print("INVALID INPUT")
                exit()
    # while 1:
    #     win = 1
    #     for i in cannons:
    #         if i.health > 0: 
    #             win = 0
    #             break 
    #     for i in buildings:
    #         if i.health > 0: 
    #             win = 0
    #             break
    #     for i in huts:
    #         if i.health > 0: 
    #             win = 0
    #             break
    #     if Village.TH.health > 0: 
    #         break
    #     if win == 0: break  
    #     if win == 1:    
    #         print(Fore.RED + "You are victorious" + Fore.RESET)
    #         exit()

    #while 1:
       
    loose=1
     #Uncomment this if you want to see barbarians to die
    if count_bar < max_bar: 
        loose=0 
    for i in barbarians:
        if i.health > 0:
            loose=0 
            break
    if lead.health > 0: 
        loose=0
    if loose==1 :
        print(Fore.RED + "You have been defeated" +Fore.RESET)
        c=builtins.input("Do you want to try again (y/n) :")
        if(c=="y"):
            return level
        elif(c=="n"):
            print("hope to see you again")
            exit()
        else :
            print("INVALID INPUT")
            exit()
    
    return 0
        