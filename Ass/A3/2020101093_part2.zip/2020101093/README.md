# clash-of-clans

## village 


### Huts:

- max health=45

 - 'h1'- hut1

 - 'h2' -hut2

 - 'h3'-hut3

 - 'h4'-hut4

 - 'h5'-hut5


### Spawning points:


- 's1'-sp1

- 's2'-sp2

- 's3'-sp3


### Town hall:

- max health=90
- represented by 't'

### walls:
- represented with wall number
- each wall object is stored in 
- max health=51

### building:

 - max health=51

 - 'b1'-building1

 - 'b2'-building2



### cannons:

- default damage value=10

- max health =60
- range = 4
- 'c1' -cannon1

- 'c2'-cannon2
### wizard towers:
- default damage value=10

- max health =51
- range= 4
- 'z1' -tower1

- 'z2'-tower2



## king :

- default damage value = 35
- maxhealth = 5000
- speed =1
- initial co-ordiantes = ( 0,0 )
## Archer Queen :
- default damage value = 30
- maxhealth = 4000
- speed =1
- initial co-ordiantes = ( 0,0 )


## barbarians :

- default damage value = 25
- default health value = 50
- max num=5

## archers :
- default damage value = 25/2 =12
- default health value = 50/2=25
- range = 5 > cannon
- max num=3

## baloons :
- default damage value = 25*2 =50
- default health value = 50
- max num =2

## spells:
- press 'r' key to activate ragespell
- press 'h' key to activate heal spell

health >50% is represented by magenta.

## levels:
- There are atmost 3 levels in the game
    Level 1: 2 cannons and 2 wizard towers
    Level 2: 3 cannons and 3 wizard towers
    Level 3: 4 cannons and 4 wizard towers


