



class characteristics:
    damage = -1 
    health = -1
    Maxhealth = -1

